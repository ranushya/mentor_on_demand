package com.java.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.java.Entity.Trainings;
import com.java.Entity.User;

public interface UserRepository extends JpaRepository<User,Long> {
	
	@Query(value="SELECT * FROM trainings   WHERE trainings.status='approved'", nativeQuery=true)
	//public List<Trainings> getAllResponse(@Param("tid") long  tid);
	public List<Trainings> getAllResponse();

}
