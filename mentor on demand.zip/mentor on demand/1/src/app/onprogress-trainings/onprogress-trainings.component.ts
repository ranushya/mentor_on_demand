import { Component, OnInit } from '@angular/core';
import { MentorService } from '../Mentor.service';
import { Trainings } from '../Trainings';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-onprogress-trainings',
  templateUrl: './onprogress-trainings.component.html',
  styleUrls: ['./onprogress-trainings.component.css']
})
export class OnprogressTrainingsComponent implements OnInit {

  onProgressTrainings: Observable<Trainings[]>;

  constructor(private mentorservice: MentorService) { }
 

  ngOnInit() {
    
    this.reloadData();
  }

  reloadData() {
  
    this.onProgressTrainings = this.mentorservice.getOnProgressTrainings();
   }
  

}
