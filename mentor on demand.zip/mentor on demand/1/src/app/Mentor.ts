export class Mentor{
    mid:number;
    mentor_name:String;
    linkedin_url:String;
    reg_datetime:Date;
    reg_code:String;
    active:boolean;
    year_of_experience:number;

}