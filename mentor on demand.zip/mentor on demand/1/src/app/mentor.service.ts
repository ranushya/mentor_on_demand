import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class MentorService {
 
  private baseUrl= 'http://localhost:8089/api/trainings';

  constructor(private http: HttpClient) { }

  getCompletedTrainings(): Observable<any> {
    return this.http.get(`${this.baseUrl}`+ `/getCompleted`);
  }

  getOnProgressTrainings(): Observable<any> {
    return this.http.get(`${this.baseUrl}`+`/getOnProgress`);
  }

  getMentorProposals(): Observable<any> {
    return this.http.get(`${this.baseUrl}`+`/viewProposals`);
  }

  private baseUrl3 = 'http://localhost:8089/api/trainings/getApprove/4';
  approveProposal( value: any): Observable<Object> {
    return this.http.put(`${this.baseUrl3}`, value);
  }
  
  private baseUrl2 = 'http://localhost:8089/api/trainings/rejectProposal/5';
  deleteProposal( value: any): Observable<any> {
    return this.http.put(`${this.baseUrl2}`, value);
  }

  private baseUrl4 = 'http://localhost:8089/api/user/getResponse/5';
  getApproveProposals(): Observable<any> {
    return this.http.get(`${this.baseUrl}`+`/viewProposals`);
  }
  
}
