import { Component, OnInit } from '@angular/core';
import { MentorService } from '../Mentor.service';
import { Trainings } from '../Trainings';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-completed-trainings',
  templateUrl: './completed-trainings.component.html',
  styleUrls: ['./completed-trainings.component.css']
})
export class CompletedTrainingsComponent implements OnInit {
  completedTrainings: Observable<Trainings[]>;
  constructor(private mentorservice: MentorService) { }

  ngOnInit() {
    console.log("haiii");
    this.reloadData();
  }
  reloadData() {
  
    this.completedTrainings = this.mentorservice.getCompletedTrainings();
   }
  
}
