import { Component, OnInit, Input } from '@angular/core';
import { MentorService } from '../Mentor.service';
import { Trainings } from '../Trainings';
import { Observable} from 'rxjs';

@Component({
  selector: 'app-mentor-proposals',
  templateUrl: './mentor-proposals.component.html',
  styleUrls: ['./mentor-proposals.component.css']
})
export class MentorProposalsComponent implements OnInit {

  @Input() trainings: Trainings; 

  proposals : Observable<Trainings[]>;
  constructor(private mentorservice: MentorService) { }

  ngOnInit() {
    this.reloadData();
  }

  approveProposal(isApprove: String) {
    this.mentorservice.approveProposal({status: isApprove })
      .subscribe(
        data => {
          console.log(data);
          this.trainings = data as Trainings;
        },
        error => console.log(error));
  }

  rejectProposal(isApprove: String) {
    this.mentorservice.deleteProposal({status: isApprove})
      .subscribe(
        data => {
          console.log(data);
          this.trainings = data as Trainings;
        },
        error => console.log(error));
  }

  reloadData() {
  
    this.proposals = this.mentorservice.getMentorProposals();
   }

}
