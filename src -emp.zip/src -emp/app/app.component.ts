import { Component } from '@angular/core';

import { Emp } from './emp';

const EMPLOYEES: Emp[] = [
  { id: 11, name: 'Mr. Nice', salary:20000,department:'accounts'},
  { id: 12, name: 'Narco', salary:20000,department:'accounts' },
  { id: 13, name: 'Bombasto', salary:20000,department:'accounts' },
  { id: 14, name: 'Celeritas', salary:20000,department:'accounts' },
  { id: 15, name: 'Magneta', salary:20000,department:'accounts'},
  { id: 16, name: 'RubberMan', salary:20000,department:'accounts'},
  { id: 17, name: 'Dynama', salary:20000,department:'accounts'},
  { id: 18, name: 'Dr IQ', salary:20000,department:'accounts'},
  { id: 19, name: 'Magma', salary:20000,department:'accounts'},
  { id: 20, name: 'Tornado', salary:20000,department:'accounts'}
];

@Component({
  selector: 'my-app',
  template: `
    <h1>{{title}}</h1>
    <h2>Select the Employee Whom details you want</h2>
    <ul class="employees">
      <li *ngFor="let emp of employees" [class.selected]="Emp === selectedEmp" (click)="onSelect(emp)">
        {{emp.name}}
      </li>
    </ul>
    <emp-detail [emp]="selectedEmp"></emp-detail>
  `,
  styles: [`
    .selected {
      background-color: #CFD8DC !important;
      color: white;
    }
    .employees {
      margin: 0 0 2em 0;
      list-style-type: none;
      padding: 0;
      width: 10em;
    }
    .employees li {
      cursor: pointer;
      position: relative;
      left: 0;
      color: black;
      background-color: #EEE;
      margin: .5em;
      padding: .3em 0;
      height: 1.6em;
      border-radius: 4px;
    }
    .employees li.selected:hover {
      background-color: #BBD8DC !important;
      color: white;
    }
    .employees li:hover {
      color: #607D8B;
      background-color: #DDD;
      left: .1em;
    }
    .employees .text {
      position: relative;
      top: -3px;
    }
  `]
})
export class AppComponent {
  title = 'Employee Details';
  employees = EMPLOYEES;
  selectedEmp: Emp;

  onSelect(emp: Emp): void {
    this.selectedEmp = emp;
  }
}
