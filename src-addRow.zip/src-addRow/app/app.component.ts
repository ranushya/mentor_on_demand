import { Component } from '@angular/core';  
@Component({ 
    selector: 'app-root', 
    templateUrl: 'app.component.html' 
}) 
export class AppComponent {
	private fieldArray: Array<any> = [];
    private newAttribute: any = {}; 
	addFieldValue() {
        this.fieldArray.push(this.newAttribute)
        this.newAttribute = {};
    }
   
}