package com.java.repo;

import java.util.List;


import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.java.model.Trainings;

@Repository
public interface TrainingsRepository extends CrudRepository<Trainings, Long> {
	
	
	
	@Query(value="SELECT * FROM trainings  WHERE trainings.tid=tid", nativeQuery=true)
	List<Trainings> getAllDetails(@Param("tid") long  tid);
	
	@Query(value="SELECT * FROM trainings  WHERE trainings.progress=100", nativeQuery=true)
	List<Trainings> getAllCompletedTraining(@Param("user_id") long  user_id);
	
	@Query(value="SELECT * FROM trainings   WHERE trainings.progress<100", nativeQuery=true)
	List<Trainings> getAllOnProgress(@Param("user_id") long  user_id);
	
	@Query(value="SELECT * FROM trainings   WHERE trainings.status='Finalize'", nativeQuery=true)
	List<Trainings> getAllFinalize(@Param("tid") long  tid);
	
	@Query(value="SELECT * FROM trainings   WHERE trainings.status='proposed'", nativeQuery=true)
	List<Trainings> getAllApprove(@Param("tid") long  tid);


}
