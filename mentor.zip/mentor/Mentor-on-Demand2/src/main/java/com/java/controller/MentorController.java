package com.java.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.java.model.Mentor;
import com.java.model.Trainings;
import com.java.repo.MentorRepository;
import com.java.repo.TrainingsRepository;

public class MentorController {
	@Autowired
	private MentorRepository repository;

	
	@GetMapping("/mentor/getDetails/{mid}")
	public Optional<Mentor> getAllDetails(@PathVariable("mid") long mid) {
		System.out.println("Get all Trainings of id...");
		Optional<Mentor> trainings = repository.findById(mid);
		return trainings;
	}

}
