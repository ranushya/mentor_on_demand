package com.java.repo;

public interface SkillsRepository {

}
