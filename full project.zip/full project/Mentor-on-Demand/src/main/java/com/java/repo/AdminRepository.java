package com.java.repo;

import org.springframework.data.repository.CrudRepository;

import com.java.Entity.Admin;

public interface AdminRepository extends CrudRepository<Admin, Long>{
	

}
