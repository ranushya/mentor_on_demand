import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class DataServiceService {

  private _email = new BehaviorSubject<String>(this._email);
_email$ = this._email.asObservable();


private _mentorMail = new BehaviorSubject<String>(this._mentorMail);
_mentorMail$ = this._mentorMail.asObservable();
  constructor() { }

  setEmail(email: String)
  {
    
    this._email.next(email);
  }

  setMentorEmail(mentorEmail: String) {
   
    this._mentorMail.next(mentorEmail);
    console.log("This is goes fine"+this._mentorMail)

  }
}
