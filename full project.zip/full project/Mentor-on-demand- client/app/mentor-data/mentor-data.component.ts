import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mentor-data',
  templateUrl: './mentor-data.component.html',
  styleUrls: ['./mentor-data.component.css']
})
export class MentorDataComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
