import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mentor-edit',
  templateUrl: './mentor-edit.component.html',
  styleUrls: ['./mentor-edit.component.css']
})
export class MentorEditComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
