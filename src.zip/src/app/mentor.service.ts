import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class MentorService {
 
  private baseUrl= 'http://localhost:8089/api/trainings/getCompleted';

  constructor(private http: HttpClient) { }

  getCompletedTrainings(): Observable<any> {
    return this.http.get(`${this.baseUrl}`);
  }
  private baseUrl1 = 'http://localhost:8089/api/trainings/getOnProgress';
  getOnProgressTrainings(): Observable<any> {
    return this.http.get(`${this.baseUrl1}`);
  }
}
