import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { UserLoginComponent } from './user-login/user-login.component';
import { MentorLoginComponent } from './mentor-login/mentor-login.component';
import { IndexComponent } from './index/index.component';
import { UserDetailsComponent } from './user-details/user-details.component';
import { MentorDetailsComponent } from './mentor-details/mentor-details.component';
import { MentorEditComponent } from './mentor-edit/mentor-edit.component';
import { AdminDetailsComponent } from './admin-details/admin-details.component';
import { AdminLoginComponent } from './admin-login/admin-login.component';
import { CompletedTrainingsComponent } from './completed-trainings/completed-trainings.component';
import { OnprogressTrainingsComponent } from './onprogress-trainings/onprogress-trainings.component';

const routes: Routes = [
   { path: '',redirectTo :'index',pathMatch:'full'},
   { path: 'index', component: IndexComponent},
   { path: 'user-login', component: UserLoginComponent},
   { path: 'mentor-login',  component: MentorLoginComponent },
   { path: 'user-details',  component: UserDetailsComponent },
   { path: 'mentor-edit',  component: MentorEditComponent },
   { path: 'admin-details',  component: AdminDetailsComponent },
   { path: 'admin-login',  component: AdminLoginComponent },
   { path: 'mentor-details',  component: MentorDetailsComponent,
  children:[
    {path: 'completed-trainings',  component: CompletedTrainingsComponent },
    { path: 'onprogress-trainings',  component: OnprogressTrainingsComponent},
  ]
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],

  exports: [RouterModule]
})
export class AppRoutingModule { }

