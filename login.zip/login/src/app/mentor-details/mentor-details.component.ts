import { Component, OnInit } from '@angular/core';



@Component({
  selector: 'app-mentor-details',
  templateUrl: './mentor-details.component.html',
  styleUrls: ['./mentor-details.component.css']
})
export class MentorDetailsComponent implements OnInit {
 
  constructor() { }

  ngOnInit() {
   
  }
}