export class Mentor{
    mentor_id:number;
    password:String;
    mentor_name:String;
    linkedin_url:String;
    reg_datetime:Date;
    reg_code:String;
    active:boolean;
    year_of_experience:number;
    skill_id:number;
    self_rating:number;
    years_of_exp:number;
    facilities_offered:String;

}