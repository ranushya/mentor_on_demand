package com.java.model;

public class MentorSkills {

}
