package com.java.repo;

import org.springframework.data.repository.CrudRepository;

import com.java.Entity.Login;

public interface LoginRepository extends CrudRepository<Login, Long>{

}
