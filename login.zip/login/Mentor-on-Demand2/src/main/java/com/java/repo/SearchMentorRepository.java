package com.java.repo;

public interface SearchMentorRepository {

}
