import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mentor-approval',
  templateUrl: './mentor-approval.component.html',
  styleUrls: ['./mentor-approval.component.css']
})
export class MentorApprovalComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    
  }

}
