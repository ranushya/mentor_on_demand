export class Trainings{
    tid:number;
    user_id:number;
    mentor_id:number;
    skill_id:number;
    status:String;
    progress:number;
    start_date:Date;
    end_date:Date;
}