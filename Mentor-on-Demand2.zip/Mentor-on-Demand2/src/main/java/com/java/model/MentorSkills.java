package com.java.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "mentorSkills")
public class MentorSkills {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	
	@Column(name = "mid")
	private int mid;
	
	@Column(name = "sid")
	private int sid;
	
	@Column(name = "self_rating")
	private int self_rating;
	
	@Column(name = "years_of_exp")
	private int years_of_exp;
	
	@Column(name = "trainings_delivered")
	private String trainings_delivered;
	
	@Column(name = "facilities_offered")
	private String facilities_offered;

	
	public MentorSkills(long id, int mid, int sid, int self_rating, int years_of_exp, String trainings_delivered,
			String facilities_offered) {
		super();
		this.id = id;
		this.mid = mid;
		this.sid = sid;
		this.self_rating = self_rating;
		this.years_of_exp = years_of_exp;
		this.trainings_delivered = trainings_delivered;
		this.facilities_offered = facilities_offered;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public int getMid() {
		return mid;
	}

	public void setMid(int mid) {
		this.mid = mid;
	}

	public int getSid() {
		return sid;
	}

	public void setSid(int sid) {
		this.sid = sid;
	}

	public int getSelf_rating() {
		return self_rating;
	}

	public void setSelf_rating(int self_rating) {
		this.self_rating = self_rating;
	}

	public int getYears_of_exp() {
		return years_of_exp;
	}

	public void setYears_of_exp(int years_of_exp) {
		this.years_of_exp = years_of_exp;
	}

	public String getTrainings_delivered() {
		return trainings_delivered;
	}

	public void setTrainings_delivered(String trainings_delivered) {
		this.trainings_delivered = trainings_delivered;
	}

	public String getFacilities_offered() {
		return facilities_offered;
	}

	public void setFacilities_offered(String facilities_offered) {
		this.facilities_offered = facilities_offered;
	}
	
}
