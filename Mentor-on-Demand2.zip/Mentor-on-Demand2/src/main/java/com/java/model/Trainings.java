package com.java.model;

import java.sql.Date;
import java.sql.Time;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "trainings")
public class Trainings {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	
	@Column(name = "user_id")
	private int user_id;
	@Column(name = "mentor_id")
	private int mentor_id;
	@Column(name = "skill_id")
	private int skill_id;
	@Column(name = "rating")
	private int rating;
	@Column(name = "start_time")
	private Time start_time;
	
	@Column(name = "end_time")
	private Time end_time;
	
	@Column(name = "start_date")
	private Date start_date;
	
	@Column(name = "end_date")
	private Date end_date;
	@Column(name = "amount_received")
	private int amount_received;
	

}
