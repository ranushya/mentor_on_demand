package com.java.model;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "mentor")
public class Mentor {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	@Column(name = "username")
	private String username;
	@Column(name = "linkedin_url")
	private String linkedin_url;
	@Column(name = "reg_datetime")
	private Date reg_datetime;
	@Column(name = "reg_code")
	private String reg_code ;	
	@Column(name = "active")
	private boolean active ;	
	@Column(name = "year_of_experience")
	private int year_of_experience ;
	public Mentor(long id, String username, String linkedin_url, Date reg_datetime, String reg_code, boolean active,
			int year_of_experience) {
		super();
		this.id = id;
		this.username = username;
		this.linkedin_url = linkedin_url;
		this.reg_datetime = reg_datetime;
		this.reg_code = reg_code;
		this.active = active;
		this.year_of_experience = year_of_experience;
	}


	public long getId() {
		return id;
	}


	public void setId(long id) {
		this.id = id;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getLinkedin_url() {
		return linkedin_url;
	}
	public void setLinkedin_url(String linkedin_url) {
		this.linkedin_url = linkedin_url;
	}
	public Date getReg_datetime() {
		return reg_datetime;
	}
	public void setReg_datetime(Date reg_datetime) {
		this.reg_datetime = reg_datetime;
	}
	public String getReg_code() {
		return reg_code;
	}
	public void setReg_code(String reg_code) {
		this.reg_code = reg_code;
	}
	public boolean isActive() {
		return active;
	}
	public void setActive(boolean active) {
		this.active = active;
	}
	public int getYear_of_experience() {
		return year_of_experience;
	}
	public void setYear_of_experience(int year_of_experience) {
		this.year_of_experience = year_of_experience;
	}
}
