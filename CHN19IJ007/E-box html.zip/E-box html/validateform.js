function validate()
{
    var name=document.getElementById("name").value.trim();
    var password=document.getElementById("password").value;
    if (name== "")                                  
    { 
        alert("Please enter your name."); 
        return false;
    } 
    else if((name.length>30)||( name.length<2))
    {
        alert("Please enter your name."); 
        return false;
    }
    else if(/[0-9]/.test(name))
    {
        alert("contais number");
        return false;
    }
    else if(/[^a-zA-Z]/.test(name))
    {
        alert("contais spl character");
        return false;
    }
   
    else if(password=="")
    {
        alert("Please enter password."); 
        return false;
    }
    
    else{
        alert("submitted"); 
        return true;
    }

}