import { Component, Input } from '@angular/core';

import { Emp } from './emp';
@Component({
  selector: 'emp-detail',
  template: `
    <div *ngIf="emp">
      <h2>{{emp.name}} details!</h2>
      <div><label>id: </label>{{emp.id}}</div>
      <div>
        <label>Name: </label>
        <input [(ngModel)]="emp.name" placeholder="name"/>
      </div>
      <div>
        <label>Salary: </label>
        <input [(ngModel)]="emp.salary" placeholder="name"/>
      </div>
      <div>
        <label>Department: </label>
        <input [(ngModel)]="emp.department" placeholder="name"/>
      </div>
    </div>
  `
})
export class EmpDetailComponent {
  @Input() emp: Emp;
}

