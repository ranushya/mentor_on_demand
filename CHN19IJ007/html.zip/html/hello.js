function sayHello() {
 alert("Hello World, this is from js file");
}

function add(a, b)
{
var c;
c = a + b;
console.log('Can u see this?');
alert('The result is '+c);

}
function mousemove()
{
    console.log("mouse pointer is moved");
    alert("Mouse is moved out of text box");
}
function changecolour(x)
{
    x.style.background = "yellow";
}