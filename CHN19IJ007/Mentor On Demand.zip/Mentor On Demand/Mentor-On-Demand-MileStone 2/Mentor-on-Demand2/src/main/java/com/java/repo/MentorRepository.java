package com.java.repo;

import java.awt.print.Pageable;
import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;


import com.java.entity.Mentor;
import com.java.entity.MentorSkills;


public interface MentorRepository extends CrudRepository<Mentor, Long>{
			
//	@Query(value ="SELECT * FROM mentor_skills ", nativeQuery = true)
//	Optional<MentorSkills> findBySkillId(Long skill_id);
	

}
