package com.java.repo;

import java.awt.print.Pageable;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.java.entity.MentorSkills;
import com.java.entity.Skills;

public interface SkillsRepository extends CrudRepository<Skills, Long> {
	
//	@Query(value ="SELECT * FROM skills s", nativeQuery = true)
//	Optional<MentorSkills> getSkills(Long skill_id);

}
