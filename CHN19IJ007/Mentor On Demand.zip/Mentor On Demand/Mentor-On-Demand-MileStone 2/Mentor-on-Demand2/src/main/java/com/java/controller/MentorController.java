package com.java.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.java.entity.Mentor;
import com.java.entity.MentorSkills;
import com.java.entity.Trainings;
import com.java.repo.MentorRepository;
import com.java.repo.TrainingsRepository;


@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api")
public class MentorController {
	@Autowired
	private MentorRepository repository;

	
	//@GetMapping("/mentor/getSearchDetails/{skill_id}")
//	public Optional<Mentor> findBySkillId(@PathVariable("skill_id")  Long mid) {
//		System.out.println("Get all Trainings of id...");
//		Optional<Mentor> mentorDetails =repository.findById(mid);
//		return mentorDetails;
//	}
	
	
	
//	@GetMapping("/mentor/getMentorDetails/{mid}")
//	public Optional<Mentor> findByMentorId(@PathVariable("mid") long mid) {
//		System.out.println("Get all Trainings of id...");
//		Optional<Mentor> trainings = repository.findById(mid);
//		return trainings;
//	}

}
