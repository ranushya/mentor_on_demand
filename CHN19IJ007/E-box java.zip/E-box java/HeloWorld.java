import java.io.*;
import java.util.*;
class HeloWorld
{
    public static void main(String args[])
    {
        System.out.println("Helo World");
    }
}