import java.util.*;
import java.io.*;
class SetOfBoxes
{
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int i,num;
        System.out.println("Enter the number of players");
        num=sc.nextInt();
        Set
    }
}