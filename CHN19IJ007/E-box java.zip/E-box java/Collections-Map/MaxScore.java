import java.io.*;
import java.util.*;
public class MaxScore
{
    public static void main(String args[])
    {
        Scanner sc=new Scanner(System.in);
        int i,num;
        String name;
        long score;
        System.out.println("Enter the number of players");
        num=sc.nextInt();
        HashMap<String,Long> map=new HashMap<String,Long>();
        sc.nextLine();
        for(i=0;i<num;i++)
        {
            System.out.println("Enter the details of the player "+(i+1));
            name=sc.next();
            score=sc.nextLong();
            map.put(name,score);
        }
        HashMap.Entry<String,Long> maxEntry = null;

    for (HashMap.Entry<String,Long> entry : map.entrySet()) {

        if (maxEntry == null || entry.getValue().compareTo(maxEntry.getValue()) > 0) {
            maxEntry = entry;
        }
    }
    System.out.println(maxEntry.getKey());
    }
}

