import java.io.*;
import java.util.*;
public class productMain
{
    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        System.out.println("Enter the product id ");
        long id=s.nextLong();
        System.out.println("Enter the product name");
        String productName=s.next();
        System.out.println("Enter the supplier name ");
        String supplierName=s.next();
        product p=new product(id,productName,supplierName);
        p.display();
    }
}