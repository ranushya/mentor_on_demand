import java.io.*;
import java.util.*;
class replace
{
    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        String oldName,newName;
        System.out.println("Enter the content of the document");
        String content=s.nextLine();

        System.out.println("Enter the old name of the company");
        oldName=s.nextLine();
        System.out.println("Enter the new name of the company");
        newName=s.nextLine();
        
        String newContent =content.replaceAll(oldName,newName);
        System.out.println("The content of the modified document is \n" +newContent);
    }
}