import java.io.*;
import java.util.*;
class compareIntegers
{
    public static void main(String[] args) {
        int firstInteger,secondInteger;
        Scanner s=new Scanner(System.in);
        System.out.println("Enter the first number ");
        firstInteger=s.nextInt();
        System.out.println("Enter the second number");
        secondInteger=s.nextInt();
        if(firstInteger < secondInteger)
        {
            System.out.println(firstInteger+ " is less than " + secondInteger);
        }
        else if(firstInteger > secondInteger)
        {
            System.out.println(firstInteger+ " is greater than " + secondInteger);
        }
        else{
            System.out.println(firstInteger+ " is equal to " + secondInteger);
        }
    }
}