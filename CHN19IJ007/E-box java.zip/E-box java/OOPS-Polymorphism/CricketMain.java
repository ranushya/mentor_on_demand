import java.io.*;
import java.util.*;
class CricketMain
{
    public static void main(String[] args) {
        System.out.println("Menu \n 1.Player details of the delivery \n 2.Run details of the delivery ");
        Scanner s=new Scanner(System.in);
        Delivery delivery=new Delivery();
        int choice=s.nextInt();
        s.nextLine();
        if (choice==1)
        {
            System.out.println("Enter the bowler name ");
            String bowler=s.nextLine();
            System.out.println("Enter the batsman name ");
            String batsman=s.nextLine();
            delivery.displayDeliveryDetails( bowler, batsman) ;
        }
        else
        {
            System.out.println("Enter the number of runs ");
            long runs=s.nextInt();
            delivery.displayDeliveryDetails( runs);
        }
    }
}