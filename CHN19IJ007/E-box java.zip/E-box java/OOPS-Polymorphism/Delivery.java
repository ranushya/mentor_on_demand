class Delivery
{
    void displayDeliveryDetails(String bowler, String batsman) 
    {
        System.out.println("Player details of the delivery: ");
        String bowlerArray[]=bowler.split(" ");
        String batsmanArray[]=batsman.split(" ");
        System.out.println("Bowler : "+bowlerArray[1]);
        System.out.println("Batsman : "+batsmanArray[1]);
    }
    void displayDeliveryDetails(Long runs)
    {
        if(runs==4)
        {
            System.out.println("Number of runs scored in the delivery : "+runs);
            System.out.println("It is a boundary.");
        }
        else if(runs==6)
        {
            System.out.println("Number of runs scored in the delivery : "+runs);
            System.out.println("It is a Sixer.");
        }
        else{
            System.out.println("Number of runs scored in the delivery : "+runs);

        }

    }
}