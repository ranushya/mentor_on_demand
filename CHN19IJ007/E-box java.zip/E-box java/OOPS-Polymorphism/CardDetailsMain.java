import java.io.*;
import java.util.*;
class card
{
    protected String holderName; 
    protected String cardNumber; 
    protected String expiryDate; 
    public card(String holderName,String cardNumber,String expiryDate)
    {
        this.holderName=holderName;
        this.cardNumber=cardNumber;
        this.expiryDate=expiryDate;
    }
    public void setHolderName(String holderName)
    {
        this.holderName=holderName;
    }
    public String getHolderName()
    {
        return holderName;
    }
    public void setCardrNumber(String cardNumber)
    {
        this.cardNumber=cardNumber;
    }
    public String getCardNumber()
    {
        return cardNumber;
    }
    public void setExpiryDate(String expiryDate)
    {
        this.expiryDate=expiryDate;
    }
    public String getExpiryDate()
    {
        return expiryDate;
    }
}
class MembershipCard extends card{
    private int rating;
    public void setRating(int rating)
    {
        this.rating=rating;
    }
    public int getRating()
    {
        return rating;
    }
    public MembershipCard(String holderName,String cardNumber,String expiryDate,int rating)
    {
        super(holderName,cardNumber,expiryDate);
        this.rating=rating;
    }

}
class PaybackCard extends card
{
    private int pointsEarned; 
    private Double totalAmount; 
    public void setPointsEarned( int pointsEarned)
    {
        this.pointsEarned=pointsEarned;
    }
    public int getPointsEarned()
    {
        return pointsEarned;
    }
    public void setTotalEarned( Double totalAmount)
    {
        this.totalAmount=totalAmount;
    }
    public Double getTotalEarned()
    {
        return totalAmount;
    }
    public PaybackCard(String holderName,String cardNumber,String expiryDate,int pointsEarned, Double totalAmount)
    {

        super(holderName,cardNumber,expiryDate);
        this.pointsEarned=pointsEarned;
        this.totalAmount=totalAmount;
    }

}
class CardDetailsMain
{
    public static void main(String[] args) {
        System.out.println("Select the Card \n 1.Payback Card \n 2.Membership Card ");
        Scanner s=new Scanner(System.in);
        int choice=s.nextInt();
        s.nextLine();
        if(choice==1)
        {
            System.out.println("Enter the Card Details: ");
            String details=s.nextLine();
            //String detailArray[]=new String[3];
            String detailArray[]=details.split("\\|");
            String holderName=detailArray[0];
            String cardNumber=detailArray[1];
            String expiryDate=detailArray[2];
            System.out.println("Enter points in card");
            int pointsEarned=s.nextInt();
            System.out.println("Enter Amount ");
            Double totalAmount=s.nextDouble();
            PaybackCard paybackcard=new PaybackCard(holderName,cardNumber,expiryDate,pointsEarned,totalAmount);
            System.out.println(paybackcard.getHolderName()+" Payback Card Details: \n Card Number  "+paybackcard.getCardNumber()+"\n Points Earned "+paybackcard.getPointsEarned ()+"\nTotal Amount "+paybackcard.getTotalEarned());
        }
        else
        {
            System.out.println("Enter the Card Details: ");
            String details=s.nextLine();
            //String detailArray[]=new String[3];
            String detailArray[]=details.split("\\|");
            String holderName=detailArray[0];
            String cardNumber=detailArray[1];
            String expiryDate=detailArray[2];
            System.out.println("Enter rating in card ");
            int rating=s.nextInt();
            MembershipCard memberShip=new MembershipCard(holderName,cardNumber,expiryDate,rating);
            System.out.println(memberShip.getHolderName()+" Membership Card Details: \n Card Number  "+memberShip.getCardN()+"\n Ratings "+memberShip.getRating());
   


        }
    }
    
}