public class student
{
    private long employeeId;
    private String employeeName;
    private static final String COHORT_CODE = "CHNAJ19004"; 
    public student()
    {
        this.employeeId=employeeId;
        this.employeeName=employeeName;

    }
    public student(long employeeId,String employeeName)
    {
        this.employeeId=employeeId;
        this.employeeName=employeeName;
    }
    public void setEmployeeId(long employeeId)
    {
        this.employeeId=employeeId;
    }
    public  void setEmployeeName(String employeeName)
    {
        this.employeeName=employeeName;
    }
    public long getEmployeeId()
    {
        return this.employeeId;
    }
    public String getEmployeeName()
    {
        return this.employeeName;
    }
    public void display()
    {
        System.out.println(employeeId+ " "+employeeName+" "+COHORT_CODE);
    }

}