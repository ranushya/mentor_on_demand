import java.io.*;
import java.util.*;
class redCrossWhile
{
    public static void main(String args[])
    {
        Scanner s=new Scanner(System.in);
        int num,tot=0,i=0;
        num=s.nextInt();
        int numberOfRefugees[]=new int[num];
        while (i<num) {
            numberOfRefugees[i]=s.nextInt();
            tot=tot+numberOfRefugees[i];
            i++;
        }
        System.out.println(tot);
        
        
    }
}