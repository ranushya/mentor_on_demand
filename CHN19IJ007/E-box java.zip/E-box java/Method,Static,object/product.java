public class product
{
    private long id;
    private String productName,supplierName;
    product()
    {
        this.id=id;
        this.supplierName=supplierName;
        this.productName=productName;
    }
    public product(long id,String productName,String supplierName)
    {
        this.id=id;
        this.supplierName=supplierName;
        this.productName=productName;
    }
    public void setId(long id)
    {
        this.id=id;
    }
    public  void setProductName(String productName)
    {
        this.productName=productName;
    }
    public  void setSupplierName(String supplierName)
    {
        this.supplierName=supplierName;
    }
    public long getId()
    {
        return this.id;
    }
    public String getProductName()
    {
        return this.productName;
    }
    public String getSupplierName()
    {
        return this.supplierName;
    }

}