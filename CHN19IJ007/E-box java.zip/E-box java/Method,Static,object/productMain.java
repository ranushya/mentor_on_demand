import java.io.*;
import java.util.*;
public class productMain
{
    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        System.out.println("Enter the product id ");
        long id=s.nextLong();
        
        System.out.println("Enter the product name");
        String productName=s.next();
        System.out.println("Enter the supplier name ");
        String supplierName=s.next();
        product p=new product();
        p.setId(id);
        p.setProductName(productName);
        p.setSupplierName(supplierName);
        System.out.println("Product Id is "+p.getId());
        System.out.println("Product Name is "+p.getProductName());
        System.out.println("Supplier Name is "+p.getSupplierName());
    }
}