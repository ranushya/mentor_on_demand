import java.io.*;
import java.util.*;
public class profitLossMethod
{
    public static void main(String args[])
    {
        int  dozenCount,pricePerDozen,sellPrice;
        System.out.println("Enter the number of dozens of toys purchased ");
        Scanner s=new Scanner(System.in);
        dozenCount=s.nextInt();
        System.out.println("Enter the price per dozen ");
        pricePerDozen=s.nextInt();
        System.out.println("Enter the selling price of 1 toy");
        sellPrice=s.nextInt();
        float profitPercent=calculateProfit(dozenCount,pricePerDozen,sellPrice);
        System.out.printf("Sam's profit percentage is %.2f",profitPercent);
        System.out.print(" percent");

    }
    public static float calculateProfit(int dozenCount, int pricePerDozen,  int sellPrice)
    {
        float cp1Toy=((float)pricePerDozen/12);
        float profit=((float)sellPrice-cp1Toy);
        float profitper=((float)(profit/cp1Toy)*100);
        return profitper;
    }
}