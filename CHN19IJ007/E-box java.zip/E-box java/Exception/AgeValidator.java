import java.io.*;
import java.util.*;
class AgeValidator
{
    public static void main(String[] args) throws Exception  {
        Scanner s=new Scanner(System.in);
        System.out.println("Enter your age");
        int age=s.nextInt();
        try {
            if(age>19)
            {
                System.out.println("welcome to vote");
            }
            else
            {
                throw new Exception("Exception occured: InvalidAgeException: not valid");
            }
            
        } catch (Exception e) {
            System.out.println(e);
          
        }
    }
}