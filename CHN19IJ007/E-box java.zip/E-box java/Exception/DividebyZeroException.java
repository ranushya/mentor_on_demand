import java.io.*;
import java.util.*;
class DividebyZeroException
{
    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        System.out.println("Enter the 2 numbers");
        int a=s.nextInt();
        int b=s.nextInt();
        try {
            int quotient =a/b;
            System.out.println("The quotient of "+a+"/"+b+" ="+quotient );
        } catch (Exception e) {
            System.out.println("DivideByZeroException caught ");
          
        }
        finally
        {
            System.out.println("Inside finally block");
        }
    }
}