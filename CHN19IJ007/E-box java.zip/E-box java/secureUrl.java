import java.io.*;
import java.util.*;
class secureUrl
{
    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        String url;
        System.out.println("Enter the String");
        url=s.nextLine();
        System.out.println("Enter the start string");
        String startString=s.next();
        if(url.startsWith(startString))
        {
            System.out.println("\"" + url +"\""+" starts with"  + "\"" + startString +"\"");
        }
        else
        {
            System.out.println("\"" + url +"\""+" does not starts with"  + "\"" + startString +"\"");
        }
    }
}