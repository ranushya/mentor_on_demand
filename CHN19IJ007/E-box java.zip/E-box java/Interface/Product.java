import java.io.*;
import java.util.*;
class Product
{
    private long id;
    private String productName;
    private String supplierName;
    Product(long id, String productName,String supplierName)
    {
        this.id=id;
        this.productName=productName;
        this.supplierName=supplierName;
    }
}