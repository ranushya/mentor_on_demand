import java.io.*;
import java.util.*;
class Product
{
    private Long id;
    private String productName;
    private String supplierName;
    public Product(Long id,String productName,String supplierName)
    {
        this.id=id;
        this.productName=productName;
        this.supplierName=supplierName;
    } 
    public  String toString()
    {
        return id +":" +productName+ ":" +supplierName+ "\nInvoking getclass() method :"+getClass().getName();
    
    } 
}
public class DisplayProduct
{
    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        System.out.println("Enter the product id");
        Long id=s.nextLong();
        s.nextLine();
        System.out.println("Enter the product name");
        String productName=s.nextLine();
        System.out.println("Enter the supplier name");
        String supplierName=s.nextLine();
        Product p=new Product(id,productName,supplierName);
        System.out.println(p);
    }
}