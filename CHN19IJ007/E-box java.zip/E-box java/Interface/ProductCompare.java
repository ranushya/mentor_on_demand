import java.io.*;
import java.util.*;
class Product
{
    private Long id;
    private String productName;
    private String supplierName;
    public Product(Long id,String productName,String supplierName)
    {
        this.id=id;
        this.productName=productName;
        this.supplierName=supplierName;
    } 
    public Long getId()
    {
        return id;
    }
    public String getProductName()
    {
        return productName;
    }
    public String getSupplierName()
    {
        return supplierName;
    }
    public  String toString()
    {
        return "Product id is "+id +"\nProduct name is "+productName+ "\nSupplier name is " +supplierName;
    
    } 
    public boolean equals(Object o)
    {
        Product p=(Product)o;
        if(this.id.equals(p.getId()) && this.productName.equals(p.getProductName()) && this.supplierName.equals(p.getSupplierName()))
        {
            return true;
        }
        else
        {
            return false;
        }
    }
}
public class ProductCompare
{
    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        System.out.println("Enter the product id");
        Long id=s.nextLong();
        s.nextLine();
        System.out.println("Enter the product name");
        String productName=s.nextLine();
        System.out.println("Enter the supplier name");
        String supplierName=s.nextLine();
        Product p1=new Product(id,productName,supplierName);
        System.out.println(p1);
        System.out.println("Enter the product id");
        Long id1=s.nextLong();
        s.nextLine();
        System.out.println("Enter the product name");
        String productName1=s.nextLine();
        System.out.println("Enter the supplier name");
        String supplierName1=s.nextLine();
        Product p2=new Product(id1,productName1,supplierName1);
        System.out.println(p2);
        if(p1.equals(p2))
        {
            System.out.println("The two products are the same");
        }
        else{
            System.out.println("The two products are different");
        }
    }
}