import java.io.*;
import java.util.*;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
public class PlayerDetails
{
    public static void main(String[] args) throws Exception 
    {
        Scanner s=new Scanner(System.in);
        System.out.println("Menu \n 1.Cricket Player Details \n 2.Hockey Player Details \n Enter choice");
        int choice=s.nextInt();
        s.nextLine();
        if (choice==1)
        {
            System.err.println("Enter player name");
            String name=s.nextLine();
            System.out.println("Enter team name");
            String teamName=s.nextLine();
            System.out.println("Enter number of matches played");
            int noOfMatches=s.nextInt();
            System.out.println("Enter total runs scored ");
            int totalRunsScored=s.nextInt();
            System.out.println("Enter total number of wickets taken ");
            int noOfWicketsTaken=s.nextInt();
            // Class clasz = Class.forName("CricketPlayer");
            // Constructor constructor = clasz.getConstructor(new Class[]{String.class,String.class,int.class,int.class,int.class});
            // IPlayerStatistics ips = (IPlayerStatistics)constructor.newInstance(name,teamName,noOfMatches,totalRunsScored,noOfWicketsTaken);
            CricketPlayer cp=new CricketPlayer(name,teamName,noOfMatches,totalRunsScored,noOfWicketsTaken);
            cp.displayPlayerStatistics();
        }
        else 
        {
            System.out.println("Enter player name");
            String name=s.nextLine();
            System.out.println("Enter team name");
            String teamName=s.nextLine();
            System.out.println("Enter number of matches played");
            int noOfMatches=s.nextInt();
            System.out.println("Enter the position");
            String position=s.next();
            s.nextLine();
            System.out.println("Enter total number of goals taken");
            int noOfGoals=s.nextInt();
            // Class classobj = Class.forName("HockeyPlayer");
            // Constructor constructor = classobj.getConstructor(new Class[]{String.class,String.class,int.class,String.class,int.class});
            // IPlayerStatistics i = (IPlayerStatistics)constructor.newInstance(name,teamName,noOfMatches,position,noOfGoals);
            HockeyPlayer hp=new HockeyPlayer(name,teamName,noOfMatches,position,noOfGoals);
            hp.displayPlayerStatistics();

        }

    }
}
interface IPlayerStatistics
{
    public void displayPlayerStatistics();
}
abstract class player{
    protected String  name;
    protected String teamName;
    protected int noOfMatches;
    player(String name,String teamName,int noOfMatches)
    {
        this.name=name;
        this.teamName=teamName;
        this.noOfMatches=noOfMatches;
    }

}
class CricketPlayer extends player implements IPlayerStatistics
{
    private int totalRunsScored, noOfWicketsTaken;
    CricketPlayer(String name,String teamName,int noOfMatches, int totalRunsScored,int noOfWicketsTaken)
    {
        super(name,teamName,noOfMatches);
        this.totalRunsScored=totalRunsScored;
        this.noOfWicketsTaken=noOfWicketsTaken;

    }
    public void displayPlayerStatistics() 
    {
        System.out.println("Player Details");
        System.out.println("Player name : "+name+ "\n Team name : "+teamName+ "\n No of matches : "+noOfMatches+  "\n Total runsscored : "+totalRunsScored+ "\n No of wickets taken : "+noOfWicketsTaken); 
    }
}
class HockeyPlayer extends player implements IPlayerStatistics
{
    private String position;
    private int noOfGoals;
    HockeyPlayer(String name,String teamName,int noOfMatches,String position,int noOfGoals)
    {
        super(name,teamName,noOfMatches);
        this.position=position;
        this.noOfGoals=noOfGoals;
    }
    public void displayPlayerStatistics() 
    {
        System.out.println("Player Details");
        System.out.println("Player name: " +name+ "Team name: " +teamName+ "No of matches: "+noOfMatches+  "Position: "+position+ "No of goals taken: "+noOfGoals);
    }
}
