import java.io.*;
import java.util.*;
class studentMain
{
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the number of GenSc");
        int num=sc.nextInt();
        student [] s=new student[num];
        for(int i=0;i<num;i++)
        {
            System.out.println("Enter Employee id");
            int employeeId=sc.nextInt();
            sc.nextLine();
            System.out.println("Enter name");
            String employeeName=sc.nextLine();
            s[i]=new student(employeeId,employeeName);
        }
       for (int i=0;i<num;i++)
       {
           s[i].display();
       }
    }
}
