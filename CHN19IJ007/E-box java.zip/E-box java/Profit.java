import java.io.*;
import java.util.*;
class Profit
{
     public static void main(String[] args) {
        double bp=20.54;
        float sp=30.50f;
        System.out.println("Buying price is "+bp);
        System.out.print("Selling price is ");
        System.out.printf("%.2f",sp);
        
        
    }
    

}