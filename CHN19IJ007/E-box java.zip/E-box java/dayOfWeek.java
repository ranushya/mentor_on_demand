import java.io.*;
import java.util.*;
class dayOfWeek
{
    public static void main(String args[])
    {
        Scanner s=new Scanner(System.in);
        String days[]={"Sun","Mon","Tue","Wed","Thurs","Fri","Sat"};
        System.out.println("Enter the day number");
        int num=s.nextInt();
        System.out.println("Day of the week is "+days[num-1]);
    }
}