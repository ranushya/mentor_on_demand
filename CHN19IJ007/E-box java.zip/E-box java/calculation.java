import java.io.*;
import java.util.*;
class calculation
{
    public static void main(String[] args) {
        float price1,price2;
        int discount;
        Scanner s=new Scanner(System.in);
        System.out.println("Price of item 1 :");
        price1=s.nextFloat();
        System.out.println("Price of item 2 :");
        price2=s.nextFloat();
        System.out.println("Discount in percentage");
        discount=s.nextInt();
        float total=price1 + price2;
        System.out.printf("Total amount :$ %.2f",total);
        float discountAmount=(total*discount)/100;
        float newAmount= total - discountAmount;
        System.out.println("Discounted amount :$"+newAmount);
        float savedAmount=total - newAmount;
        System.out.println("Saved amount :$"+ savedAmount);
    
        
    }
}