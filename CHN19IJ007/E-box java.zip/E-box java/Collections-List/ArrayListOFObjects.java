import java.io.*;
import java.util.*;
class Player
{
    private String name,country,skill;
    public Player(String name,String country,String skill)
    {
        this.name=name;
        this.country=country;
        this.skill=skill;
    }
    public void setName(String name)
    {
        this.name=name;
    }
    public void setCountry(String country)
    {
        this.country=country;
    }
    public void setSkill(String skill)
    {
        this.skill=skill;
    }
    public  String getName()
    {
        return name;
    }
    public  String getCountry()
    {
        return country;
    }
    public  String getSkill()
    {
        return skill;
    }
    public String toString()
    {
        return String.format("%-15s %-15s %-15s",name,country,skill);

    }
}
class PlayerBO
{
    //Player p=new Player();
    
    void displayAllPlayerDetails(ArrayList playerList) 
    {
        ArrayList<Player> playerList1=new ArrayList<>(playerList);
        for(Player  p: playerList1)
        {
             System.out.println(p.toString());
        }


    }
}
class ArrayListOfObjects
{
    public static void main(String[] args)
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the number of players");
        int num=sc.nextInt();
        ArrayList<Player> playerList=new ArrayList<>();
        //Player player[]=new Player[num];
        sc.nextLine();
        for(int i=0;i<num;i++)
        {
            System.out.println("Enter the player name");
            String name=sc.nextLine();
            System.out.println("Enter the country name");
            String country=sc.nextLine();
            System.out.println("Enter the skill");
            String skill=sc.nextLine();
            Player p=new Player(name,country,skill);
            playerList.add(p);
            //System.out.println(playerList);
        }
        PlayerBO dis=new PlayerBO();
        System.out.println("Player Details");
        dis.displayAllPlayerDetails(playerList);
        
        
    }
}