import java.io.*;
import java.util.*;
class SumAndAverage
{
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int num=sc.nextInt();
        int sum=0;double avg=0;
        ArrayList<Integer> array1=new ArrayList<>();
        for(int i=0;i<num;i++)
        {
            array1.add(sc.nextInt());
        }
        
        for(int ele:array1)
        {
            sum=sum+ele;
        }
        System.out.println(sum);
        avg=(double)sum/num;
        System.out.printf("%.2f",avg);
    }
}