import java.io.*;
import java.util.*;
class redCross
{
    public static void main(String args[])
    {
        Scanner s=new Scanner(System.in);
        int num,tot=0;
        num=s.nextInt();
        int numberOfRefugees[]=new int[num];
        for (int i = 0; i < num; i++) {
            numberOfRefugees[i]=s.nextInt();
            tot=tot+numberOfRefugees[i];
        }
        System.out.println(tot);
        
    }
}