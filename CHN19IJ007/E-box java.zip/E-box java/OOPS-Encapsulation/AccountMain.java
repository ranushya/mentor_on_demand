import java.io.*;
import java.util.*;
class AccountMain
{
    public static void main(String args[])
    {
        Scanner s=new Scanner(System.in);
        System.out.println("Enter the Account Number ");
        String accNum=s.next();
        System.out.println("Enter the Account Balance ");
        int balance=s.nextInt();
        System.out.println("Enter 1 to deposit an amount, 2 to withdraw an amount ");
        int choice=s.nextInt();
        Account acc=new Account(accNum,balance);
        if (choice == 1)
        {
            System.out.println("Enter the amount to deposit ");
            int transactionAmount=s.nextInt();
            acc.deposit(transactionAmount);

        }
        else
        {
            System.out.println("Enter the amount to withdraw ");
            int transactionAmount=s.nextInt();
            acc.withdraw(transactionAmount);

        }
    }
}