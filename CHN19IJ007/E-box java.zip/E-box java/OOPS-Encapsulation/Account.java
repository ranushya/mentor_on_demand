class Account
{
    private String accNum;
    private int balance;
    public Account(String accNum,int balance)
    {
        this.accNum=accNum;
        this.balance=balance;
    }
    public void setAccNum(String accNum)
    {
        this.accNum=accNum;
    }
    public String getAccNum()
    {
        return accNum;
    }
    public int getBalance()
    {
        return balance;
    }
    public void deposit(int transactionAmount) 
    {
        balance=balance+transactionAmount;
        System.out.println("Your balance after the transaction is: "+balance);
    }
    public void withdraw(int transactionAmount) 
    {
        balance=balance-transactionAmount;
        if(balance<=0)
        {
            balance=balance+transactionAmount;
            System.out.println("insufficient balance");
            System.out.println("Your balance after the transaction is:" +balance);
        }
        else
        {
            System.out.println("Your balance after the transaction is: "+balance);
        }

    }
}