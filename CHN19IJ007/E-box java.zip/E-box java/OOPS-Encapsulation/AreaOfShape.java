import java.io.*;
import java.util.*;
class Shape
{
    protected String shapeName; 
    public Shape(String shapeName)
    {
        this.shapeName=shapeName;
    }
    public void setShapeName(String shapeName)
    {
        this.shapeName=shapeName;
    }
    public String getShapeName()
    {
        return shapeName;
    }
    public double calculateArea() 
    {
        return 0;
    }
}
class Square extends Shape
{
    int side;   
    double areaSquare;
    public Square(int side)
    {
        super("square");
        this.side=side;
    }
    public void setSide(int side)
    {
        this.side=side;
    }
    public int getSide()
    {
        return side;
    }
    public double calculateArea() 
    {
        areaSquare=(float)side*side;
        return areaSquare;
    }
}
class Rectangle extends Shape
{
    int length,breadth;
    double areaRectangle;
    public Rectangle(int length,int breadth)
    {
        super("Rectangle");
        this.length=length;
        this.breadth=breadth;
    }
    public void setLength(int length)
    {
        this.length=length;
    }
    public int getlength()
    {
        return length;
    }
    public void setBreadth(int breadth)
    {
        this.breadth=breadth;
    }
    public int getBreadth()
    {
        return breadth;
    }
    
    public double calculateArea() 
    {
        areaRectangle=(float)length*breadth;
        return areaRectangle;
    }
}
class Circle extends Shape
{
    int radius;
    double areaCircle;
    public Circle(int radius)
    {
        super("circle");
        this.radius=radius;
    }
    public void setRadius(int radius)
    {
        this.radius=radius;
    }
    public int getRadius()
    {
        return radius;
    }
    public double calculateArea() 
    {
    
        areaCircle=(float)3.14*(radius*radius);
        return areaCircle;
    }
}
class AreaOfShape
{
    public static void main(String[] args) {
        System.out.println("1. Rectangle \n 2. Square \n 3. Circle ");
        Scanner s=new Scanner(System.in);
        System.out.println("Area Calculator --- Choose your shape ");
        int choice=s.nextInt();
        String shapeName;
        
        if(choice==1)
        {

            System.out.println("Enter length and breadth: ");
            int length=s.nextInt();
            int breadth=s.nextInt();
            Rectangle rect=new Rectangle(length,breadth);
            double areaRectangle=rect.calculateArea();
            System.out.printf("Area of Rectangle is:%.2f",areaRectangle);
        }
        else if(choice==2)
        {
  
            System.out.println("Enter side: ");
            int side=s.nextInt();
            Square sqr=new Square(side);
            double areaSquare= sqr.calculateArea();
            System.out.printf("Area of Square is:%.2f",areaSquare);

        }
        else{

            System.out.println("Enter Radius: ");
            int radius=s.nextInt();
            Circle cir=new Circle(radius);
            double areaCircle= cir.calculateArea();
            System.out.printf("Area of Circle is:%.2f",areaCircle);

        }
        

    }
}