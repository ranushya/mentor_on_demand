let savedproduct=localStorage.getItem('products');
let products=JSON.parse(savedproduct);

const renderProducts = function (products) {
    let tab1 = document.querySelector('#cus-tab');

    products.forEach(function (product) {

        let tr1 = document.createElement('tr');

        let td1 = document.createElement('td');
        td1.textContent = product.name
        tr1.appendChild(td1);

        let td2 = document.createElement('td');
        td2.textContent = product.free_delivery
        tr1.appendChild(td2);



        let td3 = document.createElement('td');
        td3.textContent = product.price
        tr1.appendChild(td3);


        let td4 = document.createElement('td');
        td4.textContent = product.category
        tr1.appendChild(td4);


        

        let td5 = document.createElement('td');
        let a = document.createElement('a');
        a.href = "menu-item-list-customer-notification.html?name=" + product.name +"&free_delivery=" + product.free_delivery +
            "&price=" + product.price +  "&category=" + product.category ;
        a.textContent = "Add to cart";
        a.id="add" +product.pid;
        td5.appendChild(a);
        tr1.appendChild(td5);
        tab1.appendChild(tr1);

    });

}
renderProducts(products);

