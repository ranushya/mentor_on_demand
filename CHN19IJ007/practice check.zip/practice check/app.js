const products = [

    { name: 'Sandwich', price: 99.00, active: 'Yes', date_of_launch: '15/03/2017', category: 'Main Course', free_delivery: 'Yes' },

    { name: 'Burger', price: 129.00, active: 'Yes', date_of_launch: '12/5/2017', category: 'Main Course', free_delivery: 'No' },

    { name: 'Pizza', price: 149.00, active: 'Yes', date_of_launch: '12/07/2017', category: 'Main Course', free_delivery: 'no' },

    { name: 'Fench Fries', price: 57.00, active: 'No', date_of_launch: '23/09/2017', category: 'Staters', free_delivery: 'Yes' },

    { name: 'Choclate Browmnie', price: 32.00, active: 'Yes', date_of_launch: '08/01/2017', category: 'Dessert', free_delivery: 'Yes' }


];

let productFromStorage=localStorage.getItem('products');
if(productFromStorage===null)
{
    localStorage.setItem('products',JSON.stringify(products));
}

productFromStorage=JSON.parse(productFromStorage);



const renderProducts = function (products) {
    let tab1 = document.querySelector('#prod-tab');

    products.forEach(function (product) {

        let tr1 = document.createElement('tr');

        let td1 = document.createElement('td');
        td1.textContent = product.name
        tr1.appendChild(td1);


        let td2 = document.createElement('td');
        td2.textContent = product.price
        tr1.appendChild(td2);


        let td3 = document.createElement('td');
        td3.textContent = product.active
        tr1.appendChild(td3);


        let td4 = document.createElement('td');
        td4.textContent = product.date_of_launch    
        tr1.appendChild(td4);


        let td5 = document.createElement('td');
        td5.textContent = product.category
        tr1.appendChild(td5);


        let td6 = document.createElement('td');
        td6.textContent = product.free_delivery
        tr1.appendChild(td6);


        let td7 = document.createElement('td');
        let a = document.createElement('a');
        a.href = "edit.html?name=" + product.name +
            "&price=" + product.price + "&active=" + product.active + "&date_of_launch=" + product.date_of_launch + "&category=" + product.category + "&free_delivery=" + product.free_delivery;
        a.textContent = "Edit";
        td7.appendChild(a);
        tr1.appendChild(td7);
        tab1.appendChild(tr1);

    });

}
renderProducts(productFromStorage);
