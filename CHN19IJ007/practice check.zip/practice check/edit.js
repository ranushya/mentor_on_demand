var url_string = window.location.href;

var url =new URL(url_string);

let name = url.searchParams.get('name');

let price = url.searchParams.get('price');

let active = url.searchParams.get('active');


let date_of_launch = url.searchParams.get('date_of_launch')

let category = url.searchParams.get('category');

let free_delivery = url.searchParams.get('free_delivery');

let nameText = document.querySelector('#name');

let priceText = document.querySelector('#price');

let activeText = document.querySelector('#active');
//if(active=="document.get")

let date_of_launchText=document.querySelector('#date_of_launch');

var dl = document.getElementById('category');
var el = 0;
for (var i = 0; i < dl.options.length; i++) {

    if (dl.options[i].value === category) {
        el = i;
        break;
    }
}
dl.selectedIndex = el;

let free_deliveryText=document.querySelector('#free_delivery');

nameText.setAttribute('value', name)

priceText.setAttribute('value', price)

//activeText.setAttribute('value', active)

if(active=='Yes')
{
    document.getElementById('activeyes').checked=true;
}
else{
    document.getElementById('activeno').checked=true;
    
}

date_of_launchText.setAttribute('value',date_of_launch)

//categoryText.setAttribute('value',category)

//free_deliveryText.setAttribute('value',free_delivery)
if(free_delivery==='Yes')
{
    document.getElementById("free_delivery").checked=true;
}
else{
    document.getElementById("free_delivery").unchecked=true;
    
}

//----------------------------------------------------------------------------------------------

document.querySelector('#update').addEventListener('click', function () {

    var name = nameText.value;

    var price = priceText.value;

    var active;
    if (document.getElementById('activeyes').checked) {
        active = document.getElementById('activeyes').value;
    }
    else {
        active = document.getElementById('activeno').value;
    }



    var date_of_launch = date_of_launchText.value;

    var e = document.getElementById("category");

    var category = e.options[e.selectedIndex].value;

    var free_delivery ;

    if (document.getElementById('free_delivery').checked=true) {

        free_delivery = "Yes";
    }
    else {
        free_delivery = "No";
    }


    let productsString=localStorage.getItem('products');
    
    let product=JSON.parse(productsString);
    

    product = products.find(function (product) {

        return product.name === name;

    });

    console.log("update : " + name + price  + date_of_launch + active + category + free_delivery)

    product.name = name

    product.price = price;

    product.active=active;

    product.date_of_launch=date_of_launch;
    
    product.category=category;

    product.free_delivery=free_delivery;

    localStorage.removeItem('products');

    localStorage.setItem('products',JSON.stringify(products));

    
    window.location="C:/CHN19IJ007/practice%20check/edit-menu-item-status.html";

    renderProducts(products);

}) 
